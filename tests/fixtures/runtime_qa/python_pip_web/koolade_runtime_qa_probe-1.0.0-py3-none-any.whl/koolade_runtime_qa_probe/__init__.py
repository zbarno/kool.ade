def marker():
    return "prepared pip wheel installed offline"
